f = open("file1.txt", "r")
g = open("file2.txt", "r")
file_1_contents = []
file_2_contents = []
for num in f:
    file_1_contents.append(num)
for num in g:
    file_2_contents.append(num)
result = [int(number.strip()) for number in file_1_contents and file_2_contents if number in file_1_contents and file_2_contents]

# Write your code above 👆

print(result)